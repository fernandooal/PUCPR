public enum ResultadoJogada {
    VITORIA, EMPATE, ABERTO
}
