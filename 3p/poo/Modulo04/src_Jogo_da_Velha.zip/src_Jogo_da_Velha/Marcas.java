public enum Marcas {
    LIVRE, CRUZ, BOLA
}
