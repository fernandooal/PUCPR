public class Casa {
    public int linha;
    public int coluna;
    public Marcas marca;
    public Casa(int linha, int coluna, Marcas marca)
    {
        this.linha = linha;
        this.coluna = coluna;
        this.marca = marca;
    }
}