package src.persistence;

import src.model.Casa;
import src.exceptions.ArquivoException;
import src.exceptions.SerializacaoException;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Classe responsável pela persistência de dados do sistema IoT.
 * Gerencia a serialização/deserialização da Casa em formato binário
 * e o salvamento de logs de eventos em formato texto simples (.txt).
 *
 * EXCEÇÕES UTILIZADAS:
 * - ArquivoException: Problemas de I/O, logs, arquivos não encontrados
 * - SerializacaoException: Falhas de serialização/deserialização
 */
public class GerenciadorPersistencia {
    private String caminhoArquivo;

    /**
     * Construtor do gerenciador de persistência.
     *
     * @param caminho Caminho do arquivo para serialização
     */
    public GerenciadorPersistencia(String caminho) {
        this.caminhoArquivo = caminho;
    }

    /**
     * Salva o estado completo da casa em arquivo binário usando serialização.
     *
     * @param casa Instância da casa a ser salva
     * @throws ArquivoException Se houver problema de I/O com o arquivo
     * @throws SerializacaoException Se houver falha na serialização
     */
    public void salvarCasa(Casa casa) throws ArquivoException, SerializacaoException {
        if (casa == null) {
            throw new SerializacaoException("Casa não pode ser nula", "serialização", "Casa");
        }

        try (FileOutputStream fos = new FileOutputStream(caminhoArquivo);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            oos.writeObject(casa);
            oos.flush();

            System.out.println("Casa serializada com sucesso em: " + caminhoArquivo);

        } catch (IOException e) {
            throw new ArquivoException(
                    "Erro ao salvar casa: " + e.getMessage(),
                    "escrita",
                    caminhoArquivo
            );
        } catch (Exception e) {
            throw new SerializacaoException(
                    "Falha na serialização da casa: " + e.getMessage(),
                    "serialização",
                    "Casa"
            );
        }
    }

    /**
     * Carrega o estado da casa a partir do arquivo binário.
     *
     * @return Instância da casa carregada
     * @throws ArquivoException Se houver problema de I/O com o arquivo
     * @throws SerializacaoException Se houver falha na deserialização
     */
    public Casa carregarCasa() throws ArquivoException, SerializacaoException {
        File arquivo = new File(caminhoArquivo);

        if (!arquivo.exists()) {
            throw new ArquivoException(
                    "Arquivo não encontrado: " + caminhoArquivo,
                    "leitura",
                    caminhoArquivo
            );
        }

        try (FileInputStream fis = new FileInputStream(arquivo);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            Casa casa = (Casa) ois.readObject();

            System.out.println("Casa carregada com sucesso de: " + caminhoArquivo);
            System.out.println("- Sensores: " + casa.getSensores().size());
            System.out.println("- Atuadores: " + casa.getAtuadores().size());
            System.out.println("- Cômodos: " + casa.getComodos().size());

            return casa;

        } catch (FileNotFoundException e) {
            throw new ArquivoException(
                    "Arquivo não encontrado: " + caminhoArquivo,
                    "leitura",
                    caminhoArquivo
            );
        } catch (IOException e) {
            throw new ArquivoException(
                    "Erro ao ler arquivo: " + e.getMessage(),
                    "leitura",
                    caminhoArquivo
            );
        } catch (ClassNotFoundException e) {
            throw new SerializacaoException(
                    "Classe não encontrada durante deserialização: " + e.getMessage(),
                    "deserialização",
                    "Casa"
            );
        } catch (ClassCastException e) {
            throw new SerializacaoException(
                    "Erro de cast durante deserialização: " + e.getMessage(),
                    "deserialização",
                    "Casa"
            );
        } catch (Exception e) {
            throw new SerializacaoException(
                    "Falha na deserialização: " + e.getMessage(),
                    "deserialização",
                    "Casa"
            );
        }
    }

    /**
     * Salva um evento de log em arquivo texto simples.
     * Cria o arquivo se não existir e adiciona a linha ao final.
     *
     * @param evento String do evento a ser salvo
     * @throws ArquivoException Se houver erro ao salvar o log
     */
    public void salvarLog(String evento) throws ArquivoException {
        if (evento == null || evento.trim().isEmpty()) {
            throw new ArquivoException("Evento não pode ser nulo ou vazio", "log", "");
        }

        // Determinar o arquivo de log baseado no arquivo principal
        String arquivoLog = caminhoArquivo.replace(".bin", "_log.txt");

        try (FileWriter fw = new FileWriter(arquivoLog, true); // true = append
             BufferedWriter bw = new BufferedWriter(fw)) {

            // Adicionar timestamp e formatar evento
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String linhaLog = String.format("[%s] %s", timestamp, evento);

            bw.write(linhaLog);
            bw.newLine();
            bw.flush();

        } catch (IOException e) {
            throw new ArquivoException("Erro ao salvar log: " + e.getMessage(), "escrita", arquivoLog);
        }
    }

    /**
     * Retorna o caminho do arquivo configurado.
     *
     * @return caminho do arquivo
     */
    public String getCaminhoArquivo() {
        return caminhoArquivo;
    }

    /**
     * Define um novo caminho para o arquivo.
     *
     * @param caminhoArquivo novo caminho
     */
    public void setCaminhoArquivo(String caminhoArquivo) {
        this.caminhoArquivo = caminhoArquivo;
    }

    /**
     * Verifica se o arquivo de casa existe.
     *
     * @return true se o arquivo existe, false caso contrário
     */
    public boolean arquivoExiste() {
        return new File(caminhoArquivo).exists();
    }

    /**
     * Remove o arquivo de casa (útil para testes).
     *
     * @return true se removido com sucesso
     */
    public boolean removerArquivo() {
        File arquivo = new File(caminhoArquivo);
        return arquivo.exists() && arquivo.delete();
    }

    /**
     * Cria um novo log de teste para verificar funcionamento.
     * Útil para testes e demonstrações.
     *
     * @throws ArquivoException Se houver erro ao criar o log
     */
    public void criarLogTeste() throws ArquivoException {
        salvarLog("SISTEMA - Inicialização do monitoramento da casa");
        salvarLog("LEITURA - Sensor ST01: Temperatura 23.5°C");
        salvarLog("ACAO - Lâmpada L01: Ligada automaticamente");
        salvarLog("LEITURA - Sensor SU01: Umidade 45%");
        salvarLog("ACAO - Ar-condicionado AC01: Ajustado para 24°C");
    }
}