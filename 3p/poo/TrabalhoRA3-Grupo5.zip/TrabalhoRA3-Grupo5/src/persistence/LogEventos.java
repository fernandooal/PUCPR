package src.persistence;

import java.time.LocalDateTime;

public class LogEventos {
    private LocalDateTime timestamp;
    private String tipoEvento;
    private String dispositivo;
    private String descricao;
    private double valor;

    public LogEventos(String tipo, String dispositivo, String desc, double val) {
        this.timestamp = LocalDateTime.now();
        this.tipoEvento = tipo;
        this.dispositivo = dispositivo;
        this.descricao = desc;
        this.valor = val;
    }

    @Override
    public String toString() {
        return timestamp + ";" + tipoEvento + ";" + dispositivo + ";" + descricao + ";" + valor;
    }
}
