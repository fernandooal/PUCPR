// Versão 1.2 - de 20250601

package src.model;

import src.exceptions.AtuadorException;

import java.io.Serializable;


import java.util.ArrayList;
import java.util.List;

/**
 * Representa um cômodo dentro de uma casa inteligente.
 * Cada cômodo pode conter múltiplos sensores e atuadores associados.
 *
 * @author Jafte
 */
public class Comodo implements Serializable {
    private String nome;
    private double area;
    private List<Sensor> sensores;
    private List<Atuador> atuadores;

    /**
     * Construtor da classe Comodo.
     *
     * @param nome Nome identificador do cômodo
     * @param area Área física em metros quadrados
     */
    public Comodo(String nome, double area) {
        this.nome = nome;
        this.area = area;
        this.sensores = new ArrayList<>();
        this.atuadores = new ArrayList<>();
    }

    /**
     * Adiciona dinamicamente um sensor ou atuador ao cômodo.
     * Aceita objetos genéricos e identifica pelo tipo.
     *
     * @param dispositivo Objeto Sensor ou Atuador
     */
    public void adicionarDispositivo(Object dispositivo) {
        if (dispositivo instanceof Sensor) {
            Sensor sensor = (Sensor) dispositivo;
            if (!sensores.contains(sensor)) {
                sensores.add(sensor);
            }
        } else if (dispositivo instanceof Atuador) {
            Atuador atuador = (Atuador) dispositivo;
            if (!atuadores.contains(atuador)) {
                atuadores.add(atuador);
            }
        }
    }

    /**
     * Retorna o nome do cômodo.
     *
     * @return nome do cômodo
     */
    public String getNome() {
        return nome;
    }

    /**
     * Retorna a área do cômodo.
     *
     * @return área em metros quadrados
     */
    public double getArea() {
        return area;
    }

    /**
     * Retorna a lista de sensores associados ao cômodo.
     *
     * @return lista de sensores
     */
    public List<Sensor> getSensores() {
        return sensores;
    }

    /**
     * Retorna a lista de atuadores associados ao cômodo.
     *
     * @return lista de atuadores
     */
    public List<Atuador> getAtuadores() {
        return atuadores;
    }

    /**
    public void ligarLampadas(){
        for (Atuador atuador : atuadores) {
            if (atuador.getId().contains("L")) {
                try{
                    atuador.ligar();
//                    System.out.println(atuador.getId() + " ligado");
                } catch (AtuadorException e){
                    e.printStackTrace();
                }
            }
        }
    }*/



    /**
    public void desligarLampadas(){
        for (Atuador atuador : atuadores) {
            if (atuador.getId().contains("L")) {
                try{
                    atuador.desligar();
//                    System.out.println(atuador.getId() + " desligado");
                } catch (AtuadorException e){
                    e.printStackTrace();
                }
            }
        }
    }*/

    public void ligarLampadas() throws AtuadorException {
        for (Atuador atuador : atuadores) {
            if (atuador.getId().contains("L")) {
                atuador.ligar(); // deixamos a exceção propagar
            }
        }
    }

    public void desligarLampadas() throws AtuadorException {
        for (Atuador atuador : atuadores) {
            if (atuador.getId().contains("L")) {
                atuador.desligar(); // deixamos a exceção propagar
            }
        }
    }

}

