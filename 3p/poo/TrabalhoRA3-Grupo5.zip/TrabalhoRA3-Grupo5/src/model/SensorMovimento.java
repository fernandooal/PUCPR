package src.model;

import src.exceptions.SensorException;
import src.exceptions.AtuadorException;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SensorMovimento extends Sensor {
    private boolean movimentoDetectado;
    private int sensibilidade;
    private Comodo comodo;

    public SensorMovimento(String id, String localizacao, Comodo comodo,int sensibilidade, int x, int y) {
        super(id, localizacao, x, y);
        this.comodo = comodo;
        this.sensibilidade = sensibilidade;
        this.movimentoDetectado = false;
    }

    @Override
    public double lerValor() throws SensorException {
        if(movimentoDetectado) {
            String logMessage = String.format("MOVIMENTO DETECTADO - Sensor: %s, Localização: %s",
                    getId(), getLocalizacao());
            logLeitura(logMessage);
            return 1.0;
        } else {
            return 0.0;
        }
    }

    /**
     @Override
     public JComponent criarComponenteUI(Casa casa) {
     System.out.println(comodo.getNome());
     ImageIcon iconMovimento = new ImageIcon("resources/icons/motion_sensor_active_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
     ImageIcon iconDetectado = new ImageIcon("resources/icons/motion_sensor_alert_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");

     JButton btn = new JButton();
     btn.setBounds(getCoord_x(), getCoord_y(), 32, 32);
     btn.setIcon(iconMovimento);
     btn.setOpaque(false);
     btn.setContentAreaFilled(false);
     btn.setBorder(null);

     btn.addMouseListener(new MouseAdapter() {
     @Override
     public void mouseEntered(MouseEvent e) {
     movimentoDetectado = true;
     btn.setIcon(iconDetectado);
     comodo.ligarLampadas();
     }

     @Override
     public void mouseExited(MouseEvent e) {
     movimentoDetectado = false;
     btn.setIcon(iconMovimento);
     comodo.desligarLampadas();
     }
     });

     return btn;
     }*/

    @Override
    public JComponent criarComponenteUI(Casa casa) {
        System.out.println(comodo.getNome());

        ImageIcon iconMovimento = new ImageIcon("resources/icons/motion_sensor_active_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconDetectado = new ImageIcon("resources/icons/motion_sensor_alert_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconLampadaLigada = new ImageIcon("resources/icons/lightbulb_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconLampadaDesligada = new ImageIcon("resources/icons/light_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");


        JButton btn = new JButton();
        btn.setBounds(getCoord_x(), getCoord_y(), 32, 32);
        btn.setIcon(iconMovimento);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(null);
        btn.setToolTipText("Sensor de Movimento - " + getLocalizacao());

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                try {
                    movimentoDetectado = true;
                    btn.setIcon(iconDetectado);
                    comodo.ligarLampadas();
                    lerValor();
                    //if (comodo != null) {
                    //comodo.ligarLampadas();
                    //}
                } catch (AtuadorException | SensorException ex) {
                    ex.printStackTrace(); // ou log
                }
                // Atualiza os ícones das lâmpadas ligadas
                for (Atuador a : comodo.getAtuadores()) {
                    if (a instanceof Lampada l && a.isLigado()) {
                        l.getBotaoUI().setIcon(iconLampadaLigada); // Atualiza ícone
                    }
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                try {
                    movimentoDetectado = false;
                    btn.setIcon(iconMovimento);
                    comodo.desligarLampadas();
                    lerValor();
                    //if (comodo != null) {
                    //comodo.desligarLampadas();
                    //}
                } catch (AtuadorException | SensorException ex) {
                    //ex.printStackTrace(); // ou log
                }
                // Atualiza os ícones das lâmpadas desligadas
                for (Atuador a : comodo.getAtuadores()) {
                    if (a instanceof Lampada l && !a.isLigado()) {
                        l.getBotaoUI().setIcon(iconLampadaDesligada); // Atualiza ícone
                    }
                }
            }
        });

        return btn;
    }

}