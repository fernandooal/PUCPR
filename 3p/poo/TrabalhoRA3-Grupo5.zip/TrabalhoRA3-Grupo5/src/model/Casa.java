// Versão 1.2 - de 20250601

package src.model;

import java.io.Serializable;


import java.util.ArrayList;
import java.util.List;
import src.exceptions.SensorException;
import src.exceptions.AtuadorException;

/**
 * Representa uma casa inteligente contendo sensores, atuadores e cômodos.
 * Responsável por gerenciar a estrutura e o monitoramento de dispositivos.
 *
 * @author Jafte
 */
public class Casa implements Serializable {
    private String nome;
    private String endereco;
    private List<Sensor> sensores;
    private List<Atuador> atuadores;
    private List<Comodo> comodos;

    /**
     * Construtor da classe Casa.
     *
     * @param nome Nome identificador da casa
     * @param endereco Endereço físico ou virtual
     */
    public Casa(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
        this.sensores = new ArrayList<>();
        this.atuadores = new ArrayList<>();
        this.comodos = new ArrayList<>();
    }

    /**
     * Adiciona um sensor à casa.
     *
     * @param sensor Sensor a ser adicionado
     * @throws SensorException se o sensor for nulo ou duplicado
     */
    public void adicionarSensor(Sensor sensor) throws SensorException {
        if (sensor == null) {
            throw new SensorException("Sensor nulo", "undefined");
        }
        if (getSensorPorId(sensor.getId()) != null) {
            throw new SensorException("Sensor com ID duplicado: " + sensor.getId(), sensor.getId());
        }
        sensores.add(sensor);
    }

    /**
     * Adiciona um atuador à casa.
     *
     * @param atuador Atuador a ser adicionado
     * @throws AtuadorException se o atuador for nulo ou duplicado
     */
    public void adicionarAtuador(Atuador atuador) throws AtuadorException {
        if (atuador == null) {
            throw new AtuadorException("Atuador nulo", "undefined");
        }
        if (getAtuadorPorId(atuador.getId()) != null) {
            throw new AtuadorException("Atuador com ID duplicado: " + atuador.getId(), atuador.getId());
        }
        atuadores.add(atuador);
    }

    /**
     * Adiciona um cômodo à casa.
     *
     * @param comodo Cômodo a ser incluído
     */
    public void adicionarComodo(Comodo comodo) {
        if (comodo != null) {
            comodos.add(comodo);
        }
    }

    public List<Sensor> getSensores() {
        return sensores;
    }

    public List<Atuador> getAtuadores() {
        return atuadores;
    }

    public List<Comodo> getComodos() {
        return comodos;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    /**
     * Retorna um sensor pelo seu ID.
     *
     * @param id ID do sensor
     * @return Sensor correspondente ou null
     */
    public Sensor getSensorPorId(String id) {
        return sensores.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    /**
     * Retorna um atuador pelo seu ID.
     *
     * @param id ID do atuador
     * @return Atuador correspondente ou null
     */
    public Atuador getAtuadorPorId(String id) {
        return atuadores.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    /**
     * Executa a leitura de todos os sensores ativos da casa.
     * (Simples print no console)
     */
    public void monitorar() {
        for (Sensor sensor : sensores) {
            if (sensor.isAtivo()) {
                try {
                    double valor = sensor.lerValor();
                    System.out.println("Sensor [" + sensor.getId() + "] valor: " + valor);
                } catch (SensorException e) {
                    System.err.println("Erro ao ler sensor: " + e.getMensagem());
                }
            }
        }
    }
}
