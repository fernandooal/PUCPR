// File: src/model/Lampada.java
package src.model;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import src.exceptions.AtuadorException;

/**
 * Representa uma lâmpada na casa.
 */
public class Lampada extends Atuador {
    private int coord_x;
    private int coord_y;
    private JButton botaoUI;

    public Lampada(String id, String localizacao, int coord_x, int coord_y) {
        super(id, localizacao);
        this.coord_x = coord_x;
        this.coord_y = coord_y;
    }

    public int getCoord_x() { return coord_x; }
    public int getCoord_y() { return coord_y; }

    @Override
    public void ligar() throws AtuadorException {
        super.ligar();
    }

    @Override
    public void desligar() throws AtuadorException {
        super.desligar();
    }

    public void setBotaoUI(JButton botaoUI) {
        this.botaoUI = botaoUI;
    }

    public JButton getBotaoUI() {
        return botaoUI;
    }

    @Override
    public void executarAcao(double valor) throws AtuadorException {
        if (valor > 0) ligar(); else desligar();
    }

    @Override
    public JComponent carregarLampAcUI(Casa casa) {
        ImageIcon iconOn  = new ImageIcon("resources/icons/lightbulb_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconOff = new ImageIcon("resources/icons/light_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");

        JButton btn = new JButton();
        btn.setBounds(coord_x, coord_y, 32, 32);
        btn.setIcon(isLigado() ? iconOn : iconOff);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(null);
        this.setBotaoUI(btn);
        btn.setToolTipText("Lâmpada - " + getLocalizacao());


        Lampada self = this;
        btn.addActionListener(e -> {
            try {
                if (self.isLigado()) {
                    self.desligar();
                    btn.setIcon(iconOff);
                } else {
                    self.ligar();
                    btn.setIcon(iconOn);
                }
            } catch (AtuadorException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao alternar lâmpada " + self.getId());
            }
        });

        return btn;
    }
}