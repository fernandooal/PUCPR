package src.model;

import src.exceptions.SensorException;

import javax.swing.*;
import java.util.Random;
import java.time.LocalDateTime;

public class SensorTemperatura extends Sensor {
    private double temperaturaAtual;
    private double limiteMin;
    private double limiteMax;

    public SensorTemperatura(String id, String localizacao, double min, double max, int x, int y) {
        super(id, localizacao, x, y);
        this.limiteMin = min;
        this.limiteMax = max;
        this.temperaturaAtual = min;
    }

    @Override
    public double lerValor() throws SensorException {
        Random rand = new Random();

        temperaturaAtual = rand.nextDouble() * 100;
        setUltimaLeitura(LocalDateTime.now());

        String logMessage = String.format("TEMPERATURA EXTERNA, ID: %s, LOCALIZAÇÃO: %s, VALOR: %.1fºC",
                getId(), getLocalizacao(), temperaturaAtual);
        logLeitura(logMessage);

        return temperaturaAtual;
    }

    public boolean isTemperaturaFaixa() {
        return temperaturaAtual > limiteMin && temperaturaAtual < limiteMax;
    }

    @Override
    public JComponent criarComponenteUI(Casa casa) {
        JLabel label = new JLabel();
        label.setBounds(getCoord_x(), getCoord_y(), 200, 30);
        label.setText("Temperatura externa: ---");

        Timer timer = new Timer(5000, e -> {
            try {
                double temp = lerValor();
                label.setText(String.format("Temperatura externa: %.1f°C", temp));
            } catch (SensorException ex) {
                label.setText("Erro na leitura");
            }
        });
        timer.start();

        return label;
    }
}