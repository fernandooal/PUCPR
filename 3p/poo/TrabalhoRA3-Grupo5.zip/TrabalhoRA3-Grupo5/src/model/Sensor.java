// Versão 1.2 - de 20250601
package src.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import src.exceptions.SensorException;
import src.exceptions.ArquivoException;
import src.persistence.GerenciadorPersistencia;
import javax.swing.*;

/**
 * Classe abstrata que representa um sensor genérico no sistema de IoT.
 * Todo sensor deve implementar o método {@code lerValor}, que pode lançar exceções.
 * Cada sensor possui um estado ativo/inativo e armazena a última leitura realizada.
 *
 * As subclasses devem representar tipos específicos como SensorTemperatura, etc.
 *
 * @author Fernando
 */
public abstract class Sensor implements Serializable {
    private String id;
    private String localizacao;
    private boolean ativo;
    private LocalDateTime ultimaLeitura;
    private int coord_x;
    private int coord_y;
    protected transient GerenciadorPersistencia gp;

    /**
     * Construtor base para sensores.
     *
     * @param id Identificador único do sensor
     * @param localizacao Texto representando onde o sensor está instalado
     */
    public Sensor(String id, String localizacao, int coord_x, int coord_y) {
        this.id = id;
        this.localizacao = localizacao;
        this.coord_x = coord_x;
        this.coord_y = coord_y;
        this.ativo = true;
        this.ultimaLeitura = null;
    }

    public void setGerenciadorPersistencia(GerenciadorPersistencia gp) {
        this.gp = gp;
    }

    /**
     * Retorna o ID único do sensor.
     *
     * @return identificador do sensor
     */
    public String getId() {
        return id;
    }

    /**
     * Informa se o sensor está ativo (ligado).
     *
     * @return true se ativo, false se desligado
     */
    public boolean isAtivo() {
        return ativo;
    }

    public int getCoord_x() { return coord_x; }
    public int getCoord_y() { return coord_y; }

    /**
     * Define se o sensor está ativo.
     *
     * @param ativo true para ativar, false para desativar
     */
    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    /**
     * Retorna o local de instalação do sensor.
     *
     * @return localização do sensor
     */
    public String getLocalizacao() {
        return localizacao;
    }

    /**
     * Retorna o instante da última leitura do sensor.
     *
     * @return data e hora da última leitura (ou null se nunca leu)
     */
    public LocalDateTime getUltimaLeitura() {
        return ultimaLeitura;
    }

    public void setUltimaLeitura(LocalDateTime ultimaLeitura) { this.ultimaLeitura = ultimaLeitura; }

    protected void logLeitura(String logMessage) {
        if (gp != null) {
            try {
                gp.salvarLog(logMessage);
            } catch (ArquivoException ex) {
                System.err.println("Erro ao salvar log do sensor " + this.getId() + ": " + ex.getMessage());
            }
        }
    }

    /**
     * Realiza a leitura do valor captado pelo sensor.
     * Deve ser implementado pelas subclasses.
     *
     * @return valor lido (como double)
     * @throws SensorException se houver falha na leitura
     */
    public abstract double lerValor() throws SensorException;
    public abstract JComponent criarComponenteUI(Casa casa);
}