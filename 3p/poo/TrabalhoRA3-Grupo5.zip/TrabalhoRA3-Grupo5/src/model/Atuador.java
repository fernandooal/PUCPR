// File: src/model/Atuador.java
package src.model;

import javax.swing.JComponent;
import src.model.Casa;
import src.exceptions.AtuadorException;
import src.exceptions.ArquivoException;
import src.persistence.GerenciadorPersistencia;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Classe abstrata que representa um atuador na casa.
 */
public abstract class Atuador implements Serializable {
    private String id;
    private String localizacao;
    private boolean ligado;
    private long ultimaAcao;
    protected transient GerenciadorPersistencia gp;

    public Atuador(String id, String localizacao) {
        this.id = id;
        this.localizacao = localizacao;
        this.ligado = false;
        this.ultimaAcao = System.currentTimeMillis();
    }

    public void setGerenciadorPersistencia(GerenciadorPersistencia gp) {
        this.gp = gp;
    }

    public String getId() { return id; }
    public String getLocalizacao() { return localizacao; }
    public boolean isLigado() { return ligado; }
    public long getUltimaAcao() { return ultimaAcao; }

    /**
     * Liga o atuador.
     */
    public void ligar() throws AtuadorException {
        if (this.ligado) {
            return;
        }
        this.ligado = true;
        this.ultimaAcao = System.currentTimeMillis();
        logAcao("LIGOU", "");
    }

    /**
     * Desliga o atuador.
     */
    public void desligar() throws AtuadorException {
        if (!this.ligado) {
            return;
        }
        this.ligado = false;
        this.ultimaAcao = System.currentTimeMillis();
        logAcao("DESLIGOU", "");
    }

    protected void logAcao(String acao, String valorOuEstado) {
        if (gp != null) {
            String logMessage;
            if (acao.equals("ALTEROU A TEMPERATURA")) {
                logMessage = String.format("O USUÁRIO ALTEROU A TEMPERATURA DO ARCONDICIONADO %s NO %s PARA %sºC",
                        this.getId(), this.getLocalizacao(), valorOuEstado);
            } else {
                logMessage = String.format("O USUÁRIO %s A %s %s NO %s",
                        acao, this.getClass().getSimpleName().toUpperCase(), this.getId(), this.getLocalizacao());
            }

            try {
                gp.salvarLog(logMessage);
            } catch (ArquivoException ex) {
                System.err.println("Erro ao salvar log do atuador " + this.getId() + ": " + ex.getMessage());
            }
        }
    }

    /**
     * Executa a ação específica do atuador (ligar/desligar, etc).
     */
    public abstract void executarAcao(double valor) throws AtuadorException;

    /**
     * Cada atuador gráfico deve implementar este método para criar seu componente UI.
     */
    public abstract JComponent carregarLampAcUI(Casa casa);
}