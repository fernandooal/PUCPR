// File: src/model/ArCondicionado.java
package src.model;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.JPanel;
import src.exceptions.AtuadorException;

/**
 * Representa um ar-condicionado na casa.
 */
public class ArCondicionado extends Atuador {
    private int coord_x;
    private int coord_y;
    private double temperaturaDefinida;

    public ArCondicionado(String id, String localizacao, int coord_x, int coord_y) {
        super(id, localizacao);
        this.coord_x = coord_x;
        this.coord_y = coord_y;
        this.temperaturaDefinida = 21;
    }

    public int getCoord_x() { return coord_x; }
    public int getCoord_y() { return coord_y; }
    public double getTemperaturaDefinida() { return temperaturaDefinida; }

    @Override
    public void ligar() throws AtuadorException {
        super.ligar();
    }

    @Override
    public void desligar() throws AtuadorException {
        super.desligar();
    }

    public void setTemperatura(double temperatura) {
        if (this.temperaturaDefinida == temperatura) {
            return;
        }
        this.temperaturaDefinida = temperatura;
        logAcao("ALTEROU A TEMPERATURA", String.format("%.1f", temperatura));
    }

    @Override
    public void executarAcao(double valor) throws AtuadorException {
        if (valor > 0) ligar(); else desligar();
    }

    @Override
    public JComponent carregarLampAcUI(Casa casa) {
        JPanel panel = new JPanel(null);
        panel.setOpaque(false);
        panel.setBounds(coord_x, coord_y, 64, 32);

        ImageIcon iconOn   = new ImageIcon("resources/icons/ac_unit_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconOff  = new ImageIcon("resources/icons/ac_unit_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");
        ImageIcon iconTerm = new ImageIcon("resources/icons/thermostat_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png");

        JButton btnOnOff = new JButton();
        btnOnOff.setBounds(0, 0, 32, 32);
        btnOnOff.setIcon(isLigado() ? iconOn : iconOff);
        btnOnOff.setOpaque(false);
        btnOnOff.setContentAreaFilled(false);
        btnOnOff.setBorder(null);
        ArCondicionado self = this;
        btnOnOff.addActionListener(e -> {
            try {
                if (self.isLigado()) {
                    self.desligar();
                    btnOnOff.setIcon(iconOff);
                } else {
                    self.ligar();
                    btnOnOff.setIcon(iconOn);
                }
            } catch (AtuadorException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao alternar AC " + self.getId());
            }
        });
        panel.add(btnOnOff);

        JButton btnTermo = new JButton();
        btnTermo.setBounds(32, 0, 32, 32);
        btnTermo.setIcon(iconTerm);
        btnTermo.setOpaque(false);
        btnTermo.setContentAreaFilled(false);
        btnTermo.setBorder(null);
        btnTermo.addActionListener(e -> {
            JSlider slider = new JSlider(JSlider.VERTICAL, 17, 30, (int) self.getTemperaturaDefinida());
            slider.setMajorTickSpacing(1);
            slider.setPaintTicks(true);
            slider.setPaintLabels(true);

            int opt = JOptionPane.showConfirmDialog(
                    null,
                    slider,
                    "Temperatura - " + self.getId(),
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );
            if (opt == JOptionPane.OK_OPTION) {
                self.setTemperatura(slider.getValue());
            }
        });
        panel.add(btnTermo);

        return panel;
    }
}