package src.exceptions;

import java.time.LocalDateTime;

public abstract class PersistenciaException extends Exception {
    protected String operacao;
    protected String arquivo;
    protected LocalDateTime timestamp;

    public PersistenciaException(String mensagem, String operacao) {
        super(mensagem);
        this.operacao = operacao;
        this.timestamp = LocalDateTime.now();
    }

    public PersistenciaException(String mensagem, String operacao, String arquivo) {
        super(mensagem);
        this.operacao = operacao;
        this.arquivo = arquivo;
        this.timestamp = LocalDateTime.now();
    }

    public String getOperacao() {
        return operacao;
    }

    public String getArquivo() {
        return arquivo;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    // Método protegido para uso pelas subclasses
    protected void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    // Retorna informações detalhadas sobre a exceção
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName())
                .append(" [")
                .append(timestamp)
                .append("] ")
                .append("Operação: ").append(operacao);

        if (arquivo != null) {
            sb.append(", Arquivo: ").append(arquivo);
        }

        sb.append(" - ").append(getMessage());

        return sb.toString();
    }
}