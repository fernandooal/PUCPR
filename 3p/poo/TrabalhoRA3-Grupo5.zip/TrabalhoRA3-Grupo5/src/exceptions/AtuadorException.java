package src.exceptions;

public class AtuadorException extends IoTException {
    private String atuadorId;

    public AtuadorException(String mensagem, String atuadorId) {
        super(mensagem);
        this.atuadorId = atuadorId;
    }

    public String getAtuadorId() {
        return atuadorId;
    }
}
