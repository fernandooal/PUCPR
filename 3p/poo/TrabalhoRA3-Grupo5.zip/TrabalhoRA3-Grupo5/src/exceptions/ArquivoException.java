package src.exceptions;

public class ArquivoException extends PersistenciaException {
    private String caminhoArquivo;

    public ArquivoException(String mensagem, String operacao, String caminho) {
        super(mensagem, operacao);
        this.caminhoArquivo = caminho;
    }

    public String getCaminhoArquivo() {
        return caminhoArquivo;
    }
}