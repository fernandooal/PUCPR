package src.exceptions;

import java.time.LocalDateTime;

public abstract class IoTException extends Exception {
    protected String mensagem;
    protected LocalDateTime timestamp;

    public IoTException(String mensagem) {
        super(mensagem);
        this.mensagem = mensagem;
        this.timestamp = LocalDateTime.now();
    }

    public String getMensagem() {
        return mensagem;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
