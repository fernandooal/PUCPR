package src.exceptions;

public class SensorException extends IoTException {
    private String sensorId;

    public SensorException(String mensagem, String sensorId) {
        super(mensagem);
        this.sensorId = sensorId;
    }

    public String getSensorId() {
        return sensorId;
    }
}
