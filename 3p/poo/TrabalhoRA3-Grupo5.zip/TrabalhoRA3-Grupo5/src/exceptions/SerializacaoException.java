package src.exceptions;

public class SerializacaoException extends PersistenciaException{
    private String tipoObjeto;

    public SerializacaoException(String mensagem, String operacao, String tipo) {
        super(mensagem, operacao);
        this.tipoObjeto = tipo;
    }

    public String getTipoObjeto() {
        return tipoObjeto;
    }
}