package src.exceptions;

import java.time.LocalDateTime;

/**
 * Exceção lançada quando há falhas na interface gráfica ou carregamento de dados da GUI.
 * Subclasse concreta de IoTException.
 */
public class InterfaceException extends IoTException {

    public InterfaceException(String mensagem) {
        super(mensagem);
    }
}