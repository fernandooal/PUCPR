package src.system;

import src.model.*;
import src.exceptions.*;
import src.persistence.GerenciadorPersistencia;

import java.util.*;
import java.time.LocalDateTime;

/**
 * Classe responsável pelo monitoramento contínuo da casa inteligente.
 * Executa leitura de sensores e aciona atuadores automaticamente conforme valores capturados.
 *
 * @author Jafte
 * @version 1.0
 */
public class SistemaMonitoramento {
    private Casa casa;
    private boolean monitorandoAtivo = false;
    private GerenciadorPersistencia gp;

    /**
     * Construtor padrão que recebe a instância da casa a ser monitorada.
     *
     * @param casa Casa contendo sensores e atuadores
     */
    public SistemaMonitoramento(Casa casa) {
        this.casa = casa;
        this.gp = new GerenciadorPersistencia("data/casa.bin");
    }

    /**
     * Inicia o monitoramento contínuo dos sensores e executa automações nos atuadores.
     *
     * @throws IoTException Se ocorrer erro interno durante o processo
     */
    public void iniciarMonitoramento() throws IoTException {
        monitorandoAtivo = true;
        System.out.println("Monitoramento iniciado.");

        new Thread(() -> {
            while (monitorandoAtivo) {
                try {
                    injetarGerenciadorPersistenciaNosDispositivos();
                    processarLeituras();
                    executarAutomacao();
                    Thread.sleep(3000);
                } catch (SensorException | AtuadorException e) {
                    System.err.println("Erro durante monitoramento: " + e.getMessage());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }

    /**
     * Encerra o loop de monitoramento.
     */
    public void pararMonitoramento() {
        monitorandoAtivo = false;
        System.out.println("Monitoramento encerrado.");
    }

    private void injetarGerenciadorPersistenciaNosDispositivos() {
        for (Sensor sensor : casa.getSensores()) {
            sensor.setGerenciadorPersistencia(gp);
        }
        for (Atuador atuador : casa.getAtuadores()) {
            atuador.setGerenciadorPersistencia(gp);
        }
    }

    /**
     * Processa leituras de todos os sensores registrados na casa.
     *
     * @throws SensorException Se ocorrer erro ao ler sensores
     */
    public void processarLeituras() throws SensorException {
        for (Sensor sensor : casa.getSensores()) {
            if (sensor.isAtivo()) {
                sensor.lerValor();
            }
        }
    }

    /**
     * Executa ações automáticas em atuadores com base em valores de sensores.
     *
     * @throws AtuadorException Se ocorrer erro ao acionar algum atuador
     */
    public void executarAutomacao() throws AtuadorException {
        for (Atuador atuador : casa.getAtuadores()) {
            if (atuador instanceof ArCondicionado ac) {
            }
        }
    }
}