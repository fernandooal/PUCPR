package src.system;

import src.model.*;
import src.persistence.GerenciadorPersistencia;
import src.exceptions.*;
import java.io.File;
import java.util.*;

/**
 * Programa P1 - Criador de Objetos
 * Lê dados de dispositivos.csv e cria a estrutura da casa inteligente,
 * salvando tudo em formato binário para uso posterior pelo P2.
 *
 * FORMATO CSV SUPORTADO:
 * TIPO;ID;LOCALIZACAO;PARAM1;PARAM2;PARAM3;COMODO;COORD_X;COORD_Y
 *
 * TRATAMENTO DE EXCEÇÕES:
 * - ArquivoException: Problemas de I/O, arquivo não encontrado, formato inválido
 * - SensorException: Erros específicos na criação de sensores (preserva sensorId)
 * - AtuadorException: Erros específicos na criação de atuadores (preserva atuadorId)
 *
 * @author Renato
 * @version 2.0 - Suporte ao novo formato CSV com coordenadas
 */
public class P1_CriadorObjetos {

    public static void main(String[] args) {
        try {
            Casa casa = lerDadosArquivo("data/dispositivos.csv");
            GerenciadorPersistencia gp = new GerenciadorPersistencia("data/casa.bin");
            gp.salvarCasa(casa);

            System.out.println("Casa salva com sucesso em: casa.bin");
            System.out.println("Arquivo de log será gerado como: casa_log.txt");

        } catch (ArquivoException e) {
            System.err.println("Erro de arquivo: " + e.getMessage());
            System.err.println("Operação: " + e.getOperacao());
            if (e.getArquivo() != null) {
                System.err.println("Arquivo: " + e.getArquivo());
            }
            e.printStackTrace();
        } catch (SensorException e) {
            System.err.println("Erro ao criar sensor: " + e.getMessage());
            System.err.println("Sensor ID: " + e.getSensorId());
            e.printStackTrace();
        } catch (AtuadorException e) {
            System.err.println("Erro ao criar atuador: " + e.getMessage());
            System.err.println("Atuador ID: " + e.getAtuadorId());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Erro geral: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Lê o arquivo CSV e constrói a estrutura da casa com todos os dispositivos.
     *
     * @param arquivo Nome do arquivo CSV a ser lido
     * @return Casa completa com todos os dispositivos
     * @throws ArquivoException Se houver problema na leitura do arquivo
     */
    private static Casa lerDadosArquivo(String arquivo) throws ArquivoException, SensorException, AtuadorException {
        try (Scanner scanner = new Scanner(new File(arquivo))) {
            Casa casa = null;
            Map<String, Comodo> comodos = new HashMap<>();

            while (scanner.hasNextLine()) {
                String linha = scanner.nextLine().trim();

                // Pular comentários e linhas vazias
                if (linha.startsWith("#") || linha.isEmpty()) continue;
                String[] dados = linha.split(";", -1);
                String tipo = dados[0];

                try {
                    switch (tipo) {
                        case "CASA":
                            casa = new Casa(dados[1], dados[2]);
                            break;

                        case "COMODO":
                            if (casa != null) {
                                Comodo comodo = new Comodo(dados[1], Double.parseDouble(dados[3]));
                                casa.adicionarComodo(comodo);
                                comodos.put(dados[1], comodo); // Para referência posterior
                            }
                            break;

                        case "SENSOR_TEMPERATURA":
                            if (casa != null) {
                                SensorTemperatura sensor = new SensorTemperatura(
                                        dados[1], dados[2],
                                        Double.parseDouble(dados[3]),
                                        Double.parseDouble(dados[4]),
                                        Integer.parseInt(dados[7]),
                                        Integer.parseInt(dados[8])
                                );
                                casa.adicionarSensor(sensor);

                                // Adicionar ao cômodo se especificado
                                if (comodos.containsKey(dados[6])) {
                                    comodos.get(dados[6]).adicionarDispositivo(sensor);
                                }
                            }
                            break;

                        case "SENSOR_MOVIMENTO":
                            if (casa != null) {
                                // Cria o sensor com os dados do CSV, associando ao cômodo correto
                                SensorMovimento sensor = new SensorMovimento(
                                        dados[1],                // ID
                                        dados[2],                // Local
                                        comodos.get(dados[6]),   // Cômodo (associado via chave)
                                        Integer.parseInt(dados[3]), // Sensibilidade
                                        Integer.parseInt(dados[7]), // Coordenada X
                                        Integer.parseInt(dados[8])  // Coordenada Y
                                );

                                casa.adicionarSensor(sensor); // Adiciona à casa

                                // Garante que o sensor seja incluído na lista de dispositivos do cômodo
                                if (comodos.containsKey(dados[6])) {
                                    comodos.get(dados[6]).adicionarDispositivo(sensor); // Necessário para interação com lampadas do cômodo
                                }
                            }
                            break;


/**
                        case "SENSOR_MOVIMENTO":
                            if (casa != null) {
                                SensorMovimento sensor = new SensorMovimento(
                                        dados[1], dados[2], comodos.get(dados[6]),
                                        Integer.parseInt(dados[3]),
                                        Integer.parseInt(dados[7]),
                                        Integer.parseInt(dados[8])
                                );
                                casa.adicionarSensor(sensor);



                                // Adicionar ao cômodo se especificado
                                if (comodos.containsKey(dados[6])) {
                                    comodos.get(dados[6]).adicionarDispositivo(sensor);
                                }
                            }
                            break;
*/


                        case "LAMPADA":
                            if (casa != null) {
                                Lampada lampada = new Lampada(dados[1], dados[2], Integer.parseInt(dados[7]), Integer.parseInt(dados[8]));
                                casa.adicionarAtuador(lampada);

                                // Adicionar ao cômodo se especificado
                                if (comodos.containsKey(dados[6])) {
                                    comodos.get(dados[6]).adicionarDispositivo(lampada);
                                }
                            }
                            break;

                        case "AR_CONDICIONADO":
                            if (casa != null) {
                                ArCondicionado ac = new ArCondicionado(dados[1], dados[2], Integer.parseInt(dados[7]), Integer.parseInt(dados[8]));
                                casa.adicionarAtuador(ac);

                                // Adicionar ao cômodo se especificado
                                if (dados.length > 5 && comodos.containsKey(dados[6])) {
                                    comodos.get(dados[6]).adicionarDispositivo(ac);
                                }
                            }
                            break;



                        default:
                            System.out.println("Tipo desconhecido ignorado: " + tipo);
                            break;
                    }
                } catch (SensorException | AtuadorException e) {
                    // Re-lançar exceções de dispositivos para preservar informações específicas
                    throw e;
                } catch (NumberFormatException e) {
                    throw new ArquivoException("Erro de formato numérico na linha: " + linha, "parsing", arquivo);
                }
            }

            if (casa == null) {
                throw new ArquivoException("Arquivo não contém definição de CASA", "leitura", arquivo);
            }

            return casa;

        } catch (java.io.FileNotFoundException e) {
            throw new ArquivoException("Arquivo não encontrado: " + arquivo, "leitura", arquivo);
        } catch (java.io.IOException e) {
            throw new ArquivoException("Erro de I/O ao ler arquivo: " + e.getMessage(), "leitura", arquivo);
        }
    }
}