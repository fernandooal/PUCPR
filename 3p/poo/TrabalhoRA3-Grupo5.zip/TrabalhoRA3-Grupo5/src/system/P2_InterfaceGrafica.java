package src.system;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

import src.model.Casa;
import src.model.Sensor;
import src.model.Atuador;
import src.model.Lampada;
import src.model.ArCondicionado;
import src.exceptions.AtuadorException;
import src.exceptions.SensorException;
import src.exceptions.ArquivoException;
import src.persistence.GerenciadorPersistencia;

public class P2_InterfaceGrafica {
    private Casa casa;
    private List<Sensor> sensores;
    private List<Atuador> atuadores;
    private List<Lampada> lampadas = new ArrayList<>();
    private List<JButton> botoesLampadas = new ArrayList<>();
    private List<ArCondicionado> arCondicionados = new ArrayList<>();
    private JFrame frame;
    private JLabel planta;
    private GerenciadorPersistencia gp;

    public P2_InterfaceGrafica(Casa casa) {
        this.casa = casa;
        this.gp = new GerenciadorPersistencia("data/casa.bin");
        inicializarInterface();
    }

    public static void main(String[] args) {
        try {
            GerenciadorPersistencia gpMain = new GerenciadorPersistencia("data/casa.bin");
            Casa casa = gpMain.carregarCasa();
            SwingUtilities.invokeLater(() -> new P2_InterfaceGrafica(casa));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void inicializarInterface() {
        frame = new JFrame("Casa Inteligente - Simulação Gráfica");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setLayout(new BorderLayout());

        ImageIcon plantaIcone = new ImageIcon("resources/PlantaCasa.jpg");
        planta = new JLabel(plantaIcone);
        planta.setLayout(null);

        carregarSensores(planta);
        carregarAtuadores(planta);

        frame.add(planta);
        frame.setResizable(false); // <- Trava o redirecionamento da Janela.
        frame.setVisible(true);
    }

    private void carregarSensores(JLabel planta) {
        this.sensores = casa.getSensores();
        for (Sensor s : sensores) {
            s.setGerenciadorPersistencia(gp);
            JComponent uiComponent = s.criarComponenteUI(casa);
            planta.add(uiComponent);
        }
    }

    private void carregarAtuadores(JLabel planta) {
        this.atuadores = casa.getAtuadores();
        lampadas.clear(); botoesLampadas.clear(); arCondicionados.clear();
        for (Atuador a : atuadores) {
            a.setGerenciadorPersistencia(gp);

            if (a instanceof Lampada lamp) {
                JButton btn = (JButton) lamp.carregarLampAcUI(casa);
                lampadas.add(lamp);
                botoesLampadas.add(btn);

                for (java.awt.event.ActionListener al : btn.getActionListeners()) {
                    btn.removeActionListener(al);
                }
                btn.addActionListener(e -> {
                    try {
                        if (lamp.isLigado()) {
                            lamp.desligar();
                            btn.setIcon(new ImageIcon("resources/icons/light_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                        } else {
                            lamp.ligar();
                            btn.setIcon(new ImageIcon("resources/icons/lightbulb_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                        }
                    } catch (AtuadorException ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao alternar lâmpada " + lamp.getId() + ": " + ex.getMessage());
                    }
                });

                planta.add(btn);
            } else if (a instanceof ArCondicionado ac) {
                JPanel panel = (JPanel) ac.carregarLampAcUI(casa);
                arCondicionados.add(ac);

                JButton btnOnOff = (JButton) panel.getComponent(0);
                for (java.awt.event.ActionListener al : btnOnOff.getActionListeners()) {
                    btnOnOff.removeActionListener(al);
                }
                btnOnOff.addActionListener(e -> {
                    try {
                        if (ac.isLigado()) {
                            ac.desligar();
                            btnOnOff.setIcon(new ImageIcon("resources/icons/ac_unit_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                        } else {
                            ac.ligar();
                            btnOnOff.setIcon(new ImageIcon("resources/icons/ac_unit_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                        }
                    } catch (AtuadorException ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao alternar AC " + ac.getId() + ": " + ex.getMessage());
                    }
                });

                JButton btnTermo = (JButton) panel.getComponent(1);
                for (java.awt.event.ActionListener al : btnTermo.getActionListeners()) {
                    btnTermo.removeActionListener(al);
                }
                btnTermo.addActionListener(e -> {
                    JSlider slider = new JSlider(JSlider.VERTICAL, 17, 30, (int) ac.getTemperaturaDefinida());
                    slider.setMajorTickSpacing(1);
                    slider.setPaintTicks(true);
                    slider.setPaintLabels(true);

                    int opt = JOptionPane.showConfirmDialog(
                            null,
                            slider,
                            "Temperatura - " + ac.getId(),
                            JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.PLAIN_MESSAGE
                    );
                    if (opt == JOptionPane.OK_OPTION) {
                        ac.setTemperatura(slider.getValue());
                    }
                });

                planta.add(panel);
            }
        }
        carregarControlesGeraisLampadas(planta);
        carregarControlesGeraisAC(planta);
    }

    private void carregarControlesGeraisLampadas(JLabel planta) {
        JButton btnLigarTodas = new JButton(new ImageIcon("resources/icons/light_mode_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
        btnLigarTodas.setBounds(370, 50, 32, 32);
        btnLigarTodas.setOpaque(false); btnLigarTodas.setContentAreaFilled(false); btnLigarTodas.setBorder(null);
        btnLigarTodas.setToolTipText("Ligar todas as lâmpadas");
        btnLigarTodas.addActionListener(e -> {
            boolean todasLigadas = lampadas.stream().allMatch(Lampada::isLigado);
            if (todasLigadas) { JOptionPane.showMessageDialog(null, "Todas as lâmpadas já estão ligadas."); return; }
            for (int i = 0; i < lampadas.size(); i++) {
                Lampada lamp = lampadas.get(i);
                if (!lamp.isLigado()) {
                    try {
                        lamp.ligar();
                        botoesLampadas.get(i).setIcon(new ImageIcon("resources/icons/lightbulb_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                    } catch (AtuadorException ex) { ex.printStackTrace(); }
                }
            }
        });
        JButton btnDesligarTodas = new JButton(new ImageIcon("resources/icons/dark_mode_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
        btnDesligarTodas.setBounds(400, 50, 32, 32);
        btnDesligarTodas.setOpaque(false); btnDesligarTodas.setContentAreaFilled(false); btnDesligarTodas.setBorder(null);
        btnDesligarTodas.setToolTipText("Desligar todas as lâmpadas");
        btnDesligarTodas.addActionListener(e -> {
            boolean todasDesligadas = lampadas.stream().noneMatch(Lampada::isLigado);
            if (todasDesligadas) { JOptionPane.showMessageDialog(null, "Todas as lâmpadas já estão desligadas."); return; }
            for (int i = 0; i < lampadas.size(); i++) {
                Lampada lamp = lampadas.get(i);
                if (lamp.isLigado()) {
                    try {
                        lamp.desligar();
                        botoesLampadas.get(i).setIcon(new ImageIcon("resources/icons/light_off_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
                    } catch (AtuadorException ex) { ex.printStackTrace(); }
                }
            }
        });
        planta.add(btnLigarTodas);
        planta.add(btnDesligarTodas);
    }

    private void carregarControlesGeraisAC(JLabel planta) {
        JButton btnTempGeral = new JButton(new ImageIcon("resources/icons/device_thermostat_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"));
        btnTempGeral.setBounds(430, 50, 32, 32);
        btnTempGeral.setOpaque(false); btnTempGeral.setContentAreaFilled(false); btnTempGeral.setBorder(null); btnTempGeral.setToolTipText("Ajustar temperatura geral");
        btnTempGeral.addActionListener(e -> {
            JSlider slider = new JSlider(JSlider.VERTICAL, 17, 30, 21);
            slider.setMajorTickSpacing(1); slider.setPaintTicks(true); slider.setPaintLabels(true);
            int opt = JOptionPane.showConfirmDialog(null, slider, "Temperatura Geral", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (opt == JOptionPane.OK_OPTION) {
                int temp = slider.getValue();
                arCondicionados.forEach(ac -> {
                    ac.setTemperatura(temp);
                });
            }
        });
        planta.add(btnTempGeral);
    }
}