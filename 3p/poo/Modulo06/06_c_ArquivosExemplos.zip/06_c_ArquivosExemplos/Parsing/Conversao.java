public class Conversao
{
    public static void main(String[] args)
    {
        String texto_double = "3.49";
        double d = Double.parseDouble(texto_double);
        System.out.println(d);

        String texto_int = "3";
        int k = Integer.parseInt(texto_int);
        System.out.println(k);

        String texto_float = "3.49";
        float f = Float.parseFloat(texto_float);
        System.out.println(f);

        String texto_boolean = "true";
        boolean b = Boolean.parseBoolean(texto_boolean);
        System.out.println(b);
    }
}
