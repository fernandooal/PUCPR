import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Teste {

    public static void main(String[] args) throws IOException {

        Reader reader = Files.newBufferedReader(Paths.get("pessoas.csv"));
        CSVReader csvReader = new CSVReaderBuilder(reader).withSkipLines(1).build();

        try
        {
            List<String[]> pessoas = csvReader.readAll();
            for (String[] p : pessoas)
                System.out.println("Nome : " + p[0] +
                        " - Idade : " + p[1] +
                        " - Email : " + p[2]);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
