import java.io.*;
import java.util.*;

public class Teste1 {
    public static void main(String[] args)
    {
        String NOME_ARQUIVO = "pessoas.csv";
        String SEPARADOR = ",";

        List<List<String>> registros = new ArrayList<>();

        try
        {
            FileReader arquivo = new FileReader(NOME_ARQUIVO);
            BufferedReader br = new BufferedReader(arquivo);
            String linha;
            while ((linha = br.readLine()) != null)
            {
                String[] tokens = linha.split(SEPARADOR);
                List<String> valores = Arrays.asList(tokens);
                registros.add(valores);
/*
                System.out.print(tokens[0] + " ");
                System.out.print(tokens[1] + " ");
                System.out.println(tokens[2]);
*/
                for (String v: valores)
                    System.out.print( v + " ");
                System.out.println();

                System.out.println("--------------------------");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("==========================");

        for (List<String> r: registros)
        {
            for (String v: r)
                System.out.print(v + " ");
            System.out.println();
        }
    }
}
