import java.io.*;
import java.util.*;

public class Teste3 {
    public static void main(String[] args)
    {
        String NOME_ARQUIVO = "pessoas.csv";
        String SEPARADOR = ",";

        List<List<String>> registros = new ArrayList<>();

        try
        {
            File arquivo = new File(NOME_ARQUIVO);
            Scanner scanner_arquivo = new Scanner(arquivo);
            String linha = scanner_arquivo.nextLine(); // lê o cabeçalho
            while (scanner_arquivo.hasNextLine())
            {
                linha = scanner_arquivo.nextLine();
                Scanner scanner_linha = new Scanner(linha);
                scanner_linha.useDelimiter(SEPARADOR);

                String nome = scanner_linha.next();
                int idade = scanner_linha.nextInt();
                String email = scanner_linha.next();

                System.out.println(nome + " " + idade + " " + email);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}