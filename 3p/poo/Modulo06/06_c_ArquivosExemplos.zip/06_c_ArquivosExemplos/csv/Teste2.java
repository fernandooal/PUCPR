import java.io.*;
import java.util.*;

public class Teste2 {
    public static void main(String[] args)
    {
        String NOME_ARQUIVO = "pessoas.csv";
        String SEPARADOR = ",";

        List<List<String>> registros = new ArrayList<>();

        try
        {
            File arquivo = new File(NOME_ARQUIVO);
            Scanner scanner_arquivo = new Scanner(arquivo);
            while (scanner_arquivo.hasNextLine())
            {
                String linha = scanner_arquivo.nextLine();
                Scanner scanner_linha = new Scanner(linha);
                scanner_linha.useDelimiter(SEPARADOR);
                List<String> valores = new ArrayList<String>();
                while (scanner_linha.hasNext())
                    valores.add(scanner_linha.next());
                registros.add(valores);

                System.out.print(valores.get(0) + " ");
                System.out.print(valores.get(1) + " ");
                System.out.println(valores.get(2));

                for (String v: valores)
                    System.out.print( v + " ");
                System.out.println();

                System.out.println("--------------------------");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("==========================");

        for (List<String> r: registros)
        {
            for (String v: r)
                System.out.print(v + " ");
            System.out.println();
        }
    }
}