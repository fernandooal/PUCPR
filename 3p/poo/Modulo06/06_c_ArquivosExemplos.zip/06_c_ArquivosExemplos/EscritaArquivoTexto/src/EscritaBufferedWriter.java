import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class EscritaBufferedWriter {
    public static void main(String[] args)
    {
        try {
            FileWriter arq = new FileWriter("arquivos\\novo.txt");
            BufferedWriter buf = new BufferedWriter(arq);
            buf.write("arquivo novo");
            buf.close();
            arq.close();
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
