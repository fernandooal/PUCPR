import java.io.*;

public class EscritaFileWriter {
    public static void main(String[] args) {
        try {
            FileWriter arq = new FileWriter("avioes.txt");
            arq.write("meus avioes\n");
            arq.write("estao voando ...");
            arq.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}
