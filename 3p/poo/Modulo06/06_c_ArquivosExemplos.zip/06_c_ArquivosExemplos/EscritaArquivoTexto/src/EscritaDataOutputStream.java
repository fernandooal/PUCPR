import java.io.*;

public class EscritaDataOutputStream {
    public static void main(String args[]) {
        try {
            FileOutputStream arq = new FileOutputStream("carros.txt");
            DataOutputStream saida = new DataOutputStream(arq);
            //arq.write(70);
            saida.writeChars( "meus carros\n" );
            saida.writeChars("estao rodando ...\n");
            saida.writeInt(100);
            saida.writeChar('\n');
            saida.writeDouble(57.8);
            saida.writeFloat(72.34F);
            saida.writeBoolean(true);
            saida.writeByte(60);
            saida.close();
            arq.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}
