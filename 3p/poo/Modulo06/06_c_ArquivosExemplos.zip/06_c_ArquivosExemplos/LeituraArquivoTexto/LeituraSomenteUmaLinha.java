import java.io.BufferedReader;
import java.io.FileReader;

public class LeituraSomenteUmaLinha {
    public static void main(String[] args)
    {
        try {
            FileReader arq = new FileReader("dados.txt");
            BufferedReader buf = new BufferedReader(arq);
            String linha = buf.readLine();
            System.out.println(linha);
            buf.close();
            arq.close();
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
