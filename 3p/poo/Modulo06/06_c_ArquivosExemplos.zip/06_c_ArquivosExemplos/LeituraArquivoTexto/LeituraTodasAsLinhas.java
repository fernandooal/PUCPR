import java.io.*;

public class LeituraTodasAsLinhas
{
    public static void main(String[] args) {
        try {
            FileReader arquivo =
                    new FileReader("dados.txt");
            BufferedReader buffer =
                    new BufferedReader(arquivo);
            String str;
            while ((str = buffer.readLine()) != null) {
                System.out.println(str);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
